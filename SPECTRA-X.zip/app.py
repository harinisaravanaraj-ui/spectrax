from __future__ import annotations
import time
import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from core.spectrum_generator import generate_spectrum
from core.signal_analysis import analyze_channels
from core.prediction import predict_next_hour, backtest_mae
from core.optimizer import score_channels, DEFAULT_WEIGHTS
from core.recommender import recommend
from utils.helpers import ensure_history

st.set_page_config(page_title="SPECTRA-X | RF Intelligence", page_icon="📡", layout="wide", initial_sidebar_state="expanded")

st.markdown("""
<style>
.block-container{padding-top:1.5rem;max-width:1500px}.hero{padding:1.2rem 1.4rem;border:1px solid #243047;border-radius:18px;background:linear-gradient(135deg,#101827,#151b2c);margin-bottom:1rem}.hero h1{margin:0;font-size:2.5rem}.hero p{margin:.35rem 0 0;color:#aab6cc}.badge{display:inline-block;padding:.3rem .65rem;border-radius:999px;background:#251d08;color:#ffd36a;font-weight:700;font-size:.78rem;letter-spacing:.05em}.card{padding:1rem 1.15rem;border:1px solid #263249;border-radius:16px;background:#111827}.rec{padding:1.5rem;border-radius:20px;border:1px solid #2f405e;background:linear-gradient(135deg,#101827,#19233a)}.rec h2{font-size:2.8rem;margin:.2rem 0}.small{color:#9aa9c0;font-size:.85rem}.ok{color:#7ee787}.warn{color:#ffd166}.bad{color:#ff7b72}
</style>
""", unsafe_allow_html=True)

if "phase" not in st.session_state: st.session_state.phase = 0.0
if "interference" not in st.session_state: st.session_state.interference = {}
if "previous_channel" not in st.session_state: st.session_state.previous_channel = None
if "last_action" not in st.session_state: st.session_state.last_action = None

history = ensure_history()
with st.sidebar:
    st.header("⚙️ Simulation Control")
    selected = st.selectbox("Channel", list(range(1, 11)), index=2)
    intensity = st.select_slider("Interference intensity", options=["Low", "Medium", "High"], value="Medium")
    amount = {"Low": 18.0, "Medium": 38.0, "High": 62.0}[intensity]
    if st.button("⚡ SIMULATE INTERFERENCE", use_container_width=True):
        st.session_state.interference[selected] = amount
        st.session_state.last_action = selected
        st.session_state.previous_channel = st.session_state.get("recommended_channel")
        st.rerun()
    if st.button("↺ Reset interference", use_container_width=True):
        st.session_state.interference = {}
        st.session_state.previous_channel = None
        st.session_state.last_action = None
        st.rerun()
    st.divider()
    st.caption("Scoring weights — configurable, illustrative, not scientifically optimal")
    weights = {}
    for key, val in DEFAULT_WEIGHTS.items(): weights[key] = st.slider(key.title(), 0.0, 1.0, float(val), 0.05)
    total = sum(weights.values())
    if total <= 0: weights = DEFAULT_WEIGHTS.copy()
    else: weights = {k:v/total for k,v in weights.items()}

psd, channels = generate_spectrum(interference=st.session_state.interference, phase=st.session_state.phase)
analysis = analyze_channels(channels, history)
pred = predict_next_hour(history, analysis)
combined = analysis.merge(pred, on="channel")
ranked = score_channels(combined, weights)
rec = recommend(ranked, st.session_state.previous_channel)
st.session_state.recommended_channel = rec["channel"]

st.markdown('<div class="hero"><span class="badge">SIMULATED / SYNTHETIC RF ENVIRONMENT</span><h1>📡 SPECTRA-X</h1><p>AI Co-Pilot for RF Spectrum Intelligence · From Spectrum Monitoring to Predictive Channel Intelligence</p></div>', unsafe_allow_html=True)

c1,c2,c3,c4 = st.columns(4)
c1.metric("Data Source", "Synthetic / Recorded Spectrum")
c2.metric("Hardware", "RTL-SDR Integration Ready")
c3.metric("System", "● ONLINE")
c4.metric("Channels", len(ranked))

if st.session_state.last_action and rec["changed"]:
    st.warning(f"⚠️ Recommended channel degraded. SPECTRA-X automatically selected CH{rec['channel']} as a better option.")

st.subheader("📈 Live Spectrum")
fig = go.Figure()
fig.add_trace(go.Scatter(x=psd.frequency, y=psd.power, mode="lines", name="PSD", line=dict(width=1.6)))
fig.add_trace(go.Scatter(x=psd.frequency, y=psd.groupby("channel")["power"].transform(lambda x: x.quantile(.1)), mode="lines", name="Noise floor", line=dict(dash="dot")))
for ch in range(1,11):
    left = psd.loc[psd.channel==ch,"band_start"].iloc[0]; right = psd.loc[psd.channel==ch,"band_end"].iloc[0]
    if ranked.loc[ranked.channel==ch,"occupancy"].iloc[0] > .45:
        fig.add_vrect(x0=left,x1=right,fillcolor="orange",opacity=.08,line_width=0)
    fig.add_vline(x=left,line_width=.5,line_dash="dot",opacity=.35)
fig.update_layout(height=430, margin=dict(l=10,r=10,t=20,b=10), xaxis_title="Frequency (MHz)", yaxis_title="Power / PSD (dBm-like)", template="plotly_dark", hovermode="x unified")
st.plotly_chart(fig, use_container_width=True)
st.caption("Synthetic PSD visualization. No live RF measurement is being claimed.")

st.subheader("🧠 Channel Intelligence")
display = ranked[["channel","frequency","occupancy","interference","snr","predicted_occupancy","predicted_stability","score","status"]].copy()
display.columns=["Channel","Frequency MHz","Occupancy","Interference","SNR-like","Pred. Occupancy","Pred. Stability","Score","Status"]
display["Occupancy"]=(display["Occupancy"]*100).round(1).astype(str)+"%"
display["Pred. Occupancy"]=(display["Pred. Occupancy"]*100).round(1).astype(str)+"%"
display["Interference"]=display["Interference"].round(1); display["SNR-like"]=display["SNR-like"].round(1); display["Pred. Stability"]=display["Pred. Stability"].round(1); display["Score"]=display["Score"].round(1)
st.dataframe(display, use_container_width=True, hide_index=True)

left,right=st.columns([1.15,.85])
with left:
    st.subheader("🤖 AI Recommendation")
    st.markdown(f'''<div class="rec"><div class="small">RECOMMENDED CHANNEL</div><h2>CH{rec['channel']}</h2><h3>{rec['score']:.1f} / 100</h3><p>Current Occupancy: <b>{rec['occupancy']*100:.1f}%</b> · Interference: <b>{rec['interference']:.1f}</b> · Predicted Stability: <b>{rec['stability']:.1f}%</b></p><p><b>WHY THIS CHANNEL?</b><br>✓ {'<br>✓ '.join(rec['reasons'])}</p></div>''', unsafe_allow_html=True)
with right:
    st.subheader("🏆 Top 3 Channels")
    medals=["🥇","🥈","🥉"]
    for i,row in ranked.head(3).iterrows():
        st.markdown(f"**{medals[len(st.session_state.get('top_seen',[])) if False else list(ranked.head(3).index).index(i)]} CH{int(row.channel)}** — {row.score:.1f} / 100 · {row.status}")

st.subheader("🔮 Next 60 Minutes Prediction")
pred_plot = pred.copy(); pred_plot["channel"]="CH"+pred_plot.channel.astype(str)
fig2=px.bar(pred_plot,x="channel",y="predicted_quality",labels={"predicted_quality":"Predicted Quality","channel":"Channel"},template="plotly_dark")
fig2.update_layout(height=330,margin=dict(l=10,r=10,t=20,b=10),yaxis_range=[0,100])
st.plotly_chart(fig2,use_container_width=True)
st.caption("Forecast uses a lightweight Ridge trend model over available synthetic history; it is a prototype prediction, not a production RF forecast.")

st.subheader("🕐 24-Hour Channel Occupancy")
pivot=history.pivot(index="timestamp",columns="channel",values="occupancy")*100
fig3=px.imshow(pivot.T,aspect="auto",labels=dict(x="Time",y="Channel",color="Occupancy %"),template="plotly_dark")
fig3.update_layout(height=360,margin=dict(l=10,r=10,t=20,b=10))
st.plotly_chart(fig3,use_container_width=True)

st.subheader("🧪 Validation & Transparency")
mae=backtest_mae(history)
v1,v2,v3=st.columns(3)
v1.metric("Prediction MAE", f"{mae*100:.2f} percentage points" if mae is not None else "N/A")
v2.metric("Recommendation response", "Interactive / recomputed")
v3.metric("Ranking consistency", "Calculated per scenario")
st.info("Validation performed using synthetic spectrum scenarios. Metrics above are calculated by the prototype; they are not claims of real-world accuracy.")

st.subheader("🔁 SPECTRA-X Intelligence Pipeline")
st.markdown("**SENSE** → **ANALYZE** → **PREDICT** → **OPTIMIZE** → **RECOMMEND** → **ADAPT**")
st.caption("Current sensing layer: synthetic spectrum. Future input contract: RTL-SDR or recorded IQ → PSD/features → same intelligence engine → prediction → optimization → recommendation.")

if st.session_state.last_action:
    st.markdown(f"**Adaptive test:** CH{st.session_state.last_action} received {int(amount)}-level synthetic interference ({intensity}). The current ranking above was recalculated from the altered spectrum.")
