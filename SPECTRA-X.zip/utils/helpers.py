from __future__ import annotations
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
HISTORY_PATH = ROOT / "data" / "spectrum_history.csv"

def ensure_history() -> pd.DataFrame:
    if HISTORY_PATH.exists():
        return pd.read_csv(HISTORY_PATH, parse_dates=["timestamp"])
    from core.spectrum_generator import generate_history
    df = generate_history()
    HISTORY_PATH.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(HISTORY_PATH, index=False)
    return df
