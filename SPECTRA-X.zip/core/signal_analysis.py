"""Channel feature extraction and transparent status classification."""
from __future__ import annotations
import pandas as pd


def classify_channel(row: pd.Series) -> str:
    occ, interf = row["occupancy"], row["interference"]
    if occ < 0.20 and interf < 25: return "FREE"
    if occ < 0.45 and interf < 50: return "LOW INTERFERENCE"
    if occ < 0.70 and interf < 70: return "MODERATE"
    return "HIGH INTERFERENCE"


def analyze_channels(channels: pd.DataFrame, history: pd.DataFrame) -> pd.DataFrame:
    df = channels.copy()
    stability = history.groupby("channel").agg(occ_mean=("occupancy", "mean"), occ_std=("occupancy", "std"),
                                                  quality_mean=("quality", "mean"), quality_std=("quality", "std")).reset_index()
    df = df.merge(stability, on="channel", how="left")
    df["historical_stability"] = (100 * (1 - (df["occ_std"].fillna(.1) / .35))).clip(0, 100)
    df["status"] = df.apply(classify_channel, axis=1)
    return df
