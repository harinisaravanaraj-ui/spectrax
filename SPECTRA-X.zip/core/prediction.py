"""Lightweight, explainable 60-minute forecasting."""
from __future__ import annotations
import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge


def predict_next_hour(history: pd.DataFrame, channels: pd.DataFrame, horizon_minutes: int = 60) -> pd.DataFrame:
    results = []
    for ch in channels["channel"]:
        h = history[history.channel == ch].sort_values("timestamp").copy()
        if len(h) >= 6:
            X = np.arange(len(h)).reshape(-1, 1)
            model = Ridge(alpha=1.0).fit(X, h["occupancy"].values)
            pred_occ = float(np.clip(model.predict([[len(h) + 1]])[0], 0, 1))
            stability = float(np.clip(100 * (1 - h["occupancy"].std(ddof=0) / 0.35), 0, 100))
        else:
            pred_occ = float(h["occupancy"].iloc[-1]) if len(h) else float(channels.loc[channels.channel == ch, "occupancy"].iloc[0])
            stability = 70.0
        current_quality = float(channels.loc[channels.channel == ch, "quality"].iloc[0])
        pred_quality = float(np.clip(current_quality * 0.65 + (100 * (1 - pred_occ)) * 0.35, 0, 100))
        results.append({"channel": ch, "predicted_occupancy": pred_occ, "predicted_stability": stability,
                        "predicted_quality": pred_quality})
    return pd.DataFrame(results)


def backtest_mae(history: pd.DataFrame) -> float | None:
    """One-step rolling validation over synthetic history; returns actual calculated MAE."""
    errors = []
    for ch, h in history.groupby("channel"):
        h = h.sort_values("timestamp")
        if len(h) < 8: continue
        for i in range(6, len(h)):
            train = h.iloc[:i]
            X = np.arange(len(train)).reshape(-1, 1)
            model = Ridge(alpha=1.0).fit(X, train["occupancy"])
            pred = float(np.clip(model.predict([[len(train)]])[0], 0, 1))
            errors.append(abs(pred - float(h.iloc[i]["occupancy"])))
    return float(np.mean(errors)) if errors else None
