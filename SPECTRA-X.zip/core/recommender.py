"""Recommendation and explainability layer."""
from __future__ import annotations
import pandas as pd


def recommend(ranked: pd.DataFrame, previous_channel: int | None = None) -> dict:
    best = ranked.iloc[0]
    reasons = []
    if best.occupancy < .30: reasons.append("Low current occupancy")
    if best.interference < 35: reasons.append("Low interference")
    if best.predicted_stability >= 75: reasons.append("Strong predicted stability")
    if best.historical_stability >= 70: reasons.append("Good historical stability")
    if not reasons: reasons.append("Best combined score across configured factors")
    changed = previous_channel is not None and int(best.channel) != int(previous_channel)
    return {"channel": int(best.channel), "score": float(best.score), "occupancy": float(best.occupancy),
            "interference": float(best.interference), "stability": float(best.predicted_stability),
            "quality": float(best.predicted_quality), "reasons": reasons, "changed": changed}
