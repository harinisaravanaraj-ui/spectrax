"""Synthetic RF spectrum source. Hardware-independent input contract for SPECTRA-X."""
from __future__ import annotations
import numpy as np
import pandas as pd

DEFAULT_FREQ_START = 430.0
DEFAULT_FREQ_END = 450.0
CHANNEL_BW = 2.0


def generate_spectrum(n_channels: int = 10, points_per_channel: int = 80,
                      seed: int = 42, interference: dict[int, float] | None = None,
                      phase: float = 0.0) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Return PSD samples and channel-level ground-truth simulation features.

    Frequencies are MHz and power is dBm-like synthetic PSD. This is explicitly not
    a physical RF measurement; the same channel-feature schema can later be fed by
    an RTL-SDR/recorded-IQ adapter.
    """
    rng = np.random.default_rng(seed)
    freqs = np.linspace(DEFAULT_FREQ_START, DEFAULT_FREQ_END, n_channels * points_per_channel)
    channel_width = (DEFAULT_FREQ_END - DEFAULT_FREQ_START) / n_channels
    rows, channel_rows = [], []
    interference = interference or {}

    for ch in range(1, n_channels + 1):
        left = DEFAULT_FREQ_START + (ch - 1) * channel_width
        right = left + channel_width
        mask = (freqs >= left) & (freqs <= right if ch == n_channels else freqs < right)
        f = freqs[mask]
        base_noise = -94 + 1.8 * np.sin(phase * 0.07 + ch * 0.8) + rng.normal(0, 1.2, f.size)
        signal_type = ["narrowband", "wideband", "intermittent", "continuous", "noise"][ch % 5]
        center = left + channel_width * (0.25 + 0.5 * ((ch * 7) % 10) / 10)
        signal = np.zeros_like(f)
        occupancy_base = 0.10 + 0.07 * ((ch * 3) % 7)
        if signal_type == "narrowband":
            signal = 28 * np.exp(-0.5 * ((f - center) / 0.10) ** 2)
        elif signal_type == "wideband":
            signal = 16 * np.exp(-0.5 * ((f - (left + right) / 2) / 0.60) ** 2)
        elif signal_type == "intermittent" and int(phase) % 4 != 2:
            signal = 24 * np.exp(-0.5 * ((f - center) / 0.16) ** 2)
        elif signal_type == "continuous":
            signal = 13 + 2 * np.sin(f * 3 + phase)
            occupancy_base = 0.82
        extra = float(interference.get(ch, 0.0))
        if extra:
            interferer_center = left + channel_width * 0.52
            signal += extra * np.exp(-0.5 * ((f - interferer_center) / 0.32) ** 2)
            occupancy_base = min(1.0, occupancy_base + extra / 70)
        psd = base_noise + signal
        threshold = -82
        occupancy = float(np.mean(psd > threshold))
        noise_level = float(np.percentile(base_noise, 90))
        signal_power = float(np.percentile(psd, 95))
        interference_level = float(np.clip((signal_power - noise_level) * 0.55 + extra * 0.5, 0, 100))
        snr = float(signal_power - noise_level)
        availability = 1 - occupancy
        quality = float(np.clip(100 * (0.45 * availability + 0.30 * (1 - interference_level / 100) +
                                     0.15 * np.clip((snr + 5) / 35, 0, 1) + 0.10), 0, 100))
        for ff, pp in zip(f, psd):
            rows.append((ff, pp, ch, left, right))
        channel_rows.append({
            "channel": ch, "frequency": (left + right) / 2, "band_start": left,
            "band_end": right, "signal_power": signal_power, "noise": noise_level,
            "occupancy": occupancy, "interference": interference_level, "snr": snr,
            "quality": quality, "signal_type": signal_type,
        })
    return pd.DataFrame(rows, columns=["frequency", "power", "channel", "band_start", "band_end"]), pd.DataFrame(channel_rows)


def generate_history(n_channels: int = 10, hours: int = 24, seed: int = 7) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    times = pd.date_range(pd.Timestamp.now().floor("h") - pd.Timedelta(hours=hours - 1), periods=hours, freq="h")
    out = []
    for ts in times:
        for ch in range(1, n_channels + 1):
            daily = 0.15 * (1 + np.sin((ts.hour / 24) * 2 * np.pi + ch * 0.6))
            occupancy = float(np.clip(0.12 + 0.055 * ch + daily + rng.normal(0, 0.055), 0.01, 0.98))
            interference = float(np.clip(12 + 3.5 * ch + 14 * occupancy + rng.normal(0, 4), 0, 100))
            noise = float(-95 + rng.normal(0, 1.5))
            quality = float(np.clip(100 * (0.58 * (1 - occupancy) + 0.32 * (1 - interference / 100) + 0.10), 0, 100))
            out.append({"timestamp": ts, "channel": ch, "frequency": DEFAULT_FREQ_START + (ch - .5) * CHANNEL_BW,
                        "occupancy": occupancy, "interference": interference, "noise": noise, "quality": quality})
    return pd.DataFrame(out)
