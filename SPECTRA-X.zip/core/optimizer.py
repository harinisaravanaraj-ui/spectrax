"""Configurable transparent channel scoring."""
from __future__ import annotations
import pandas as pd

DEFAULT_WEIGHTS = {"availability": .25, "interference": .20, "historical": .20, "prediction": .25, "noise": .10}


def score_channels(df: pd.DataFrame, weights: dict[str, float] | None = None) -> pd.DataFrame:
    w = weights or DEFAULT_WEIGHTS
    out = df.copy()
    noise_quality = ((out["noise"] + 100) / 12).clip(0, 1) * 100
    out["noise_quality"] = noise_quality
    availability = (1 - out["occupancy"]) * 100
    interference_quality = (1 - out["interference"] / 100).clip(0, 1) * 100
    out["score"] = (w["availability"] * availability + w["interference"] * interference_quality +
                    w["historical"] * out["historical_stability"] + w["prediction"] * out["predicted_stability"] +
                    w["noise"] * noise_quality).clip(0, 100)
    return out.sort_values("score", ascending=False).reset_index(drop=True)
