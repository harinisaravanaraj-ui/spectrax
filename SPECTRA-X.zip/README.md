# SPECTRA-X — AI Co-Pilot for RF Spectrum Intelligence

SPECTRA-X is a software-only RF spectrum intelligence prototype designed for a laptop demonstration when SDR hardware is unavailable. It demonstrates the complete pipeline: **SENSE → ANALYZE → PREDICT → OPTIMIZE → RECOMMEND → ADAPT**.

> **Honest prototype boundary:** the sensing layer is synthetic. The application never presents synthetic observations as live RF measurements. The dashboard labels the source as **Synthetic / Recorded Spectrum Data** and **SIMULATED / SYNTHETIC RF ENVIRONMENT**.

## Problem statement

Spectrum users need to identify usable channels in environments where occupancy, noise and interference vary over time. A conventional snapshot can show what is happening now, but a useful intelligence layer should combine current conditions, historical behavior and a near-term forecast to recommend a channel and adapt when conditions change.

## Proposed solution

SPECTRA-X generates a realistic synthetic spectrum environment, extracts channel features, predicts near-term occupancy/quality, scores channels with a transparent configurable formula, recommends the top channel and demonstrates automatic re-ranking after an injected interference event.

## Innovation

The strongest demo feature is adaptive channel selection. A judge can select a channel and interference intensity, trigger an interference event, and watch the system recalculate the spectrum features, forecast, score and recommendation without changing the intelligence layer.

## Architecture

```text
Synthetic Spectrum / Future RTL-SDR or Recorded IQ
                    ↓
             Signal Processing
                    ↓
             PSD + Features
                    ↓
           SPECTRA-X Intelligence
          ↙        ↓         ↘
     Prediction  Optimization  Explainability
          ↘        ↓         ↙
             Recommendation
                    ↓
                  Adapt
```

## Algorithm

For each channel the prototype calculates occupancy, noise, interference, signal power, an SNR-like metric and quality. A status classifier labels channels FREE, LOW INTERFERENCE, MODERATE or HIGH INTERFERENCE.

The channel score is a configurable weighted combination:

`Score = w1*Current Availability + w2*Interference Quality + w3*Historical Stability + w4*Predicted Stability + w5*Noise Quality`

The default weights are 0.25, 0.20, 0.20, 0.25 and 0.10 respectively. These are engineering-demo weights, **not scientifically optimal weights**.

## Prediction method

The forecast layer uses a lightweight Ridge regression trend over historical occupancy for each channel. It predicts near-future occupancy and combines that with current quality to estimate predicted quality. Historical occupancy variation is converted to a stability score. This avoids forcing an LSTM onto a small synthetic dataset.

## Optimization method

All channels are scored and sorted. The highest-scoring channel becomes the recommendation. The recommendation card also explains which measurable factors contributed to the choice.

## Adaptive demonstration

1. Launch the app.
2. Note the recommended channel and score.
3. In the sidebar choose that channel.
4. Select High interference.
5. Press **SIMULATE INTERFERENCE**.
6. The synthetic PSD changes and the channel's occupancy/interference/quality degrade.
7. Prediction and optimization are recomputed.
8. The ranking and recommendation card update automatically.

## Technology stack

Python 3.12, Streamlit, NumPy, Pandas, SciPy, scikit-learn and Plotly.

## Installation

```bash
python -m venv .venv
# Windows PowerShell
.\.venv\Scripts\Activate.ps1
# macOS/Linux
source .venv/bin/activate
pip install -r requirements.txt
```

## Running

```bash
streamlit run app.py
```

## Validation

The application performs a rolling one-step backtest on its synthetic historical occupancy data and reports the calculated MAE. It also exposes the adaptive recommendation behavior directly in the UI. Validation is explicitly limited to synthetic spectrum scenarios.

## Limitations

- No physical RF receiver is connected in the prototype.
- Synthetic PSD is not a substitute for measured RF/IQ data.
- The forecast is intentionally lightweight and is not validated for operational spectrum management.
- Scoring weights are illustrative and should be calibrated with real deployment data.

## RTL-SDR integration plan

Keep the downstream intelligence contract unchanged. A future adapter can replace the synthetic source with RTL-SDR or recorded IQ, perform FFT/PSD estimation and emit channel-level features with the same schema used by `signal_analysis.py`, `prediction.py` and `optimizer.py`.

Conceptually:

`RTL-SDR / Recorded IQ → PSD / Spectrum Features → SPECTRA-X Intelligence Engine → Prediction → Optimization → Recommendation`

## Future roadmap

1. Real RTL-SDR input adapter.
2. Calibrated PSD and occupancy detection.
3. Real recorded spectrum datasets for validation.
4. More robust time-series forecasting and uncertainty estimates.
5. Deployment-specific scoring calibration and alerting.
